package chatServer;

/**
 * Created by Satria on 4/28/2016.
 */
public class cobaClient {
    public static void main(String[] args){

    }
}
